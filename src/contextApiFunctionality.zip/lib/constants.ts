export const MAX_CHARACTERS = 150;
export const API_URL =
  "https://bytegrad.com/course-assets/projects/corpcomment/api/feedbacks";
