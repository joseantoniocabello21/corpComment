export default function ErrorMessage({ message }) {
  return <div>{message}</div>;
}
