export default function Pattern() {
  return (
    <img
      className="pattern"
      src="https://bytegrad.com/course-assets/js/1/pattern.svg"
      alt="pattern"
    />
  );
}
