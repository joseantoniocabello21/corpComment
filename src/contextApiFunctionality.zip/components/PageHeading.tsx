export default function PageHeading() {
  return (
    <h1>
      Give Feedback. <span>Publicly.</span>
    </h1>
  );
}
